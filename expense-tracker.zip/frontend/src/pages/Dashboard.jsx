import { useEffect, useRef, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import { FiCreditCard, FiTrendingUp, FiTrendingDown, FiPieChart, FiTarget, FiShield, FiPlus } from "react-icons/fi";
import { getDashboard } from "../services/reportService";
import { setBudget } from "../services/budgetService";
import { getErrorMessage } from "../utils/format";
import { MONTH_NAMES } from "../utils/constants";
import BalanceCard from "../components/BalanceCard";
import BudgetProgress from "../components/BudgetProgress";
import ExpenseChart from "../components/ExpenseChart";
import IncomeChart from "../components/IncomeChart";
import PieChart from "../components/PieChart";
import TransactionTable from "../components/TransactionTable";
import EmptyState from "../components/EmptyState";
import Modal from "../components/Modal";
import Loader from "../components/Loader";

const Dashboard = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [budgetOpen, setBudgetOpen] = useState(false);
  const [budgetValue, setBudgetValue] = useState("");
  const [saving, setSaving] = useState(false);
  const warned = useRef(false);

  const load = useCallback(async () => {
    try {
      const d = await getDashboard();
      setData(d);
      // Toast once per visit when spending reaches 90% of the budget
      if (d.budget.isSet && d.budget.percentage >= 90 && !warned.current) {
        warned.current = true;
        toast.warn(`You've used ${d.budget.percentage}% of this month's budget!`);
      }
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openBudget = () => {
    setBudgetValue(data.budget.isSet ? String(data.budget.monthlyBudget) : "");
    setBudgetOpen(true);
  };

  const saveBudget = async (e) => {
    e.preventDefault();
    if (!budgetValue || Number(budgetValue) <= 0) return toast.error("Enter a budget greater than 0");
    setSaving(true);
    try {
      await setBudget({ monthlyBudget: Number(budgetValue) });
      toast.success("Budget saved");
      setBudgetOpen(false);
      warned.current = false;
      load();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loader text="Loading dashboard..." />;
  if (!data) return <EmptyState title="Could not load dashboard" message="Please refresh the page." />;

  const monthLabel = `${MONTH_NAMES[data.month - 1]} ${data.year}`;
  const { budget } = data;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-800 dark:text-white">Dashboard</h1>
          <p className="text-sm text-slate-500">Overview for {monthLabel}</p>
        </div>
        <Link to="/transactions/add" className="btn-primary"><FiPlus /> Add Transaction</Link>
      </div>

      {/* Summary cards */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <BalanceCard title="Total Balance" amount={data.totalBalance} icon={FiCreditCard} gradient="bg-gradient-to-br from-primary-500 to-violet-600" subtitle="All time" />
        <BalanceCard title="Total Income" amount={data.monthIncome} icon={FiTrendingUp} gradient="bg-gradient-to-br from-emerald-400 to-teal-600" subtitle="This month" />
        <BalanceCard title="Total Expenses" amount={data.monthExpense} icon={FiTrendingDown} gradient="bg-gradient-to-br from-rose-400 to-red-600" subtitle="This month" />
        <BalanceCard title="Total Savings" amount={data.monthSavings} icon={FiPieChart} gradient="bg-gradient-to-br from-sky-400 to-blue-600" subtitle="Income − expenses, this month" />
        <BalanceCard title="Monthly Budget" amount={budget.monthlyBudget} icon={FiTarget} gradient="bg-gradient-to-br from-amber-400 to-orange-600" subtitle={budget.isSet ? "This month" : "Not set"} />
        <BalanceCard title="Remaining Budget" amount={budget.isSet ? budget.remaining : 0} icon={FiShield} gradient="bg-gradient-to-br from-fuchsia-400 to-purple-600" subtitle={budget.isSet ? "This month" : "Set a budget first"} />
      </div>

      {/* Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        <ExpenseChart data={data.monthlyTrend} />
        <IncomeChart data={data.monthlyTrend} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <PieChart data={data.categoryBreakdown} />
        <BudgetProgress budget={budget} onEdit={openBudget} />
      </div>

      {/* Recent transactions */}
      <div className="card animate-slideUp">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-semibold text-slate-800 dark:text-white">Recent Transactions</h3>
          <Link to="/transactions" className="text-sm font-semibold text-primary-600 hover:underline dark:text-primary-400">View all</Link>
        </div>
        {data.recentTransactions.length === 0 ? (
          <EmptyState title="No transactions yet" message="Add your first income or expense to get started." action={<Link to="/transactions/add" className="btn-primary">Add Transaction</Link>} />
        ) : (
          <TransactionTable transactions={data.recentTransactions} />
        )}
      </div>

      {/* Budget modal */}
      <Modal isOpen={budgetOpen} onClose={() => setBudgetOpen(false)} title={`Budget for ${monthLabel}`}>
        <form onSubmit={saveBudget} className="space-y-4">
          <div>
            <label className="label" htmlFor="budget">Monthly budget (₹)</label>
            <input id="budget" type="number" min="1" className="input" placeholder="e.g. 20000" value={budgetValue} onChange={(e) => setBudgetValue(e.target.value)} autoFocus />
          </div>
          <div className="flex gap-3">
            <button type="button" onClick={() => setBudgetOpen(false)} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" disabled={saving} className="btn-primary flex-1">{saving ? "Saving..." : "Save"}</button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Dashboard;
