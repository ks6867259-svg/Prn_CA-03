import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { useAuth } from "../context/AuthContext";
import AuthLayout from "../components/AuthLayout";
import { getErrorMessage } from "../utils/format";

const Register = () => {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", confirm: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => {
    setForm({ ...form, [k]: e.target.value });
    setErrors({ ...errors, [k]: "" });
  };

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = "Enter a valid email address";
    if (form.password.length < 6) e.password = "Password must be at least 6 characters";
    if (form.confirm !== form.password) e.confirm = "Passwords do not match";
    setErrors(e);
    return !Object.keys(e).length;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      await register({ name: form.name.trim(), email: form.email, password: form.password });
      toast.success("Account created successfully!");
      navigate("/");
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const field = (key, label, type, placeholder) => (
    <div>
      <label className="label" htmlFor={key}>{label}</label>
      <input id={key} type={type} className={`input ${errors[key] ? "input-error" : ""}`} placeholder={placeholder} value={form[key]} onChange={set(key)} />
      {errors[key] && <p className="error-text">{errors[key]}</p>}
    </div>
  );

  return (
    <AuthLayout title="Create account" subtitle="Start tracking your expenses in minutes.">
      <form onSubmit={handleSubmit} className="space-y-5" noValidate>
        {field("name", "Full name", "text", "John Doe")}
        {field("email", "Email", "email", "you@example.com")}
        {field("password", "Password", "password", "At least 6 characters")}
        {field("confirm", "Confirm password", "password", "Repeat your password")}
        <button type="submit" disabled={loading} className="btn-primary w-full">{loading ? "Creating account..." : "Sign Up"}</button>
      </form>
      <p className="mt-6 text-center text-sm text-slate-500">
        Already have an account? <Link to="/login" className="font-semibold text-primary-600 hover:underline dark:text-primary-400">Sign in</Link>
      </p>
    </AuthLayout>
  );
};

export default Register;
