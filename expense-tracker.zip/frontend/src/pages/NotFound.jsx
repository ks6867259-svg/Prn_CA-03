import { Link } from "react-router-dom";

const NotFound = () => (
  <div className="flex min-h-screen flex-col items-center justify-center px-4 text-center">
    <h1 className="bg-gradient-to-r from-primary-600 to-violet-600 bg-clip-text text-8xl font-black text-transparent">404</h1>
    <h2 className="mt-4 text-2xl font-bold text-slate-800 dark:text-white">Page not found</h2>
    <p className="mt-2 text-slate-500">The page you're looking for doesn't exist or was moved.</p>
    <Link to="/" className="btn-primary mt-8">Back to Dashboard</Link>
  </div>
);

export default NotFound;
