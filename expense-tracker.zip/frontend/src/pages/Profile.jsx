import { useRef, useState } from "react";
import { toast } from "react-toastify";
import { FiCamera, FiLogOut, FiSave, FiLock } from "react-icons/fi";
import { useAuth } from "../context/AuthContext";
import { updateProfile } from "../services/profileService";
import { getErrorMessage } from "../utils/format";
import Avatar from "../components/Avatar";

const Profile = () => {
  const { user, setUser, logout } = useAuth();
  const fileRef = useRef(null);

  // Profile details
  const [name, setName] = useState(user.name);
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);

  // Password
  const [pw, setPw] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [pwErrors, setPwErrors] = useState({});
  const [savingPw, setSavingPw] = useState(false);

  const pickImage = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    if (!f.type.startsWith("image/")) return toast.error("Please choose an image file");
    if (f.size > 2 * 1024 * 1024) return toast.error("Image must be under 2MB");
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };

  const saveProfile = async (e) => {
    e.preventDefault();
    if (!name.trim()) return toast.error("Name cannot be empty");
    const fd = new FormData();
    fd.append("name", name.trim());
    if (file) fd.append("profileImage", file);
    setSavingProfile(true);
    try {
      setUser(await updateProfile(fd));
      setFile(null);
      setPreview("");
      toast.success("Profile updated");
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSavingProfile(false);
    }
  };

  const savePassword = async (e) => {
    e.preventDefault();
    const errs = {};
    if (!pw.currentPassword) errs.currentPassword = "Current password is required";
    if (pw.newPassword.length < 6) errs.newPassword = "Must be at least 6 characters";
    if (pw.confirm !== pw.newPassword) errs.confirm = "Passwords do not match";
    setPwErrors(errs);
    if (Object.keys(errs).length) return;

    setSavingPw(true);
    try {
      await updateProfile({ currentPassword: pw.currentPassword, newPassword: pw.newPassword });
      setPw({ currentPassword: "", newPassword: "", confirm: "" });
      toast.success("Password changed");
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSavingPw(false);
    }
  };

  const pwField = (key, label) => (
    <div>
      <label className="label" htmlFor={key}>{label}</label>
      <input id={key} type="password" className={`input ${pwErrors[key] ? "input-error" : ""}`} value={pw[key]} onChange={(e) => { setPw({ ...pw, [key]: e.target.value }); setPwErrors({ ...pwErrors, [key]: "" }); }} />
      {pwErrors[key] && <p className="error-text">{pwErrors[key]}</p>}
    </div>
  );

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-800 dark:text-white">Profile</h1>
        <p className="text-sm text-slate-500">Manage your account details and security.</p>
      </div>

      <form onSubmit={saveProfile} className="card !p-6 space-y-6">
        <div className="flex flex-col items-center gap-4 sm:flex-row">
          <div className="relative">
            {preview ? (
              <img src={preview} alt="Preview" className="h-24 w-24 rounded-full object-cover ring-4 ring-primary-100 dark:ring-slate-800" />
            ) : (
              <Avatar user={user} size="h-24 w-24" text="text-3xl" />
            )}
            <button type="button" onClick={() => fileRef.current.click()} className="absolute bottom-0 right-0 rounded-full bg-primary-600 p-2 text-white shadow-lg transition hover:bg-primary-700" aria-label="Change photo">
              <FiCamera size={14} />
            </button>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={pickImage} />
          </div>
          <div className="text-center sm:text-left">
            <p className="text-lg font-bold text-slate-800 dark:text-white">{user.name}</p>
            <p className="text-sm text-slate-500">{user.email}</p>
            <p className="mt-1 text-xs text-slate-400">JPG, PNG or WEBP, max 2MB</p>
          </div>
        </div>

        <div>
          <label className="label" htmlFor="name">Full name</label>
          <input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label className="label">Email</label>
          <input className="input cursor-not-allowed opacity-60" value={user.email} disabled />
        </div>
        <button type="submit" disabled={savingProfile} className="btn-primary"><FiSave /> {savingProfile ? "Saving..." : "Save Changes"}</button>
      </form>

      <form onSubmit={savePassword} className="card !p-6 space-y-5">
        <h3 className="flex items-center gap-2 font-semibold text-slate-800 dark:text-white"><FiLock /> Change Password</h3>
        {pwField("currentPassword", "Current password")}
        <div className="grid gap-5 sm:grid-cols-2">
          {pwField("newPassword", "New password")}
          {pwField("confirm", "Confirm new password")}
        </div>
        <button type="submit" disabled={savingPw} className="btn-primary">{savingPw ? "Updating..." : "Update Password"}</button>
      </form>

      <div className="card !p-6 flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-slate-800 dark:text-white">Sign out</h3>
          <p className="text-sm text-slate-500">You will need to log in again.</p>
        </div>
        <button onClick={logout} className="btn-danger"><FiLogOut /> Logout</button>
      </div>
    </div>
  );
};

export default Profile;
