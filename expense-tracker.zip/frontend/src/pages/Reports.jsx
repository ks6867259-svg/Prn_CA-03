import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { FiDownload, FiTrendingUp, FiTrendingDown, FiPieChart } from "react-icons/fi";
import { getMonthlyReport } from "../services/reportService";
import { useAuth } from "../context/AuthContext";
import { currentMonthInput, formatCurrency, getErrorMessage } from "../utils/format";
import { CHART_COLORS, MONTH_NAMES } from "../utils/constants";
import { generateReportPDF } from "../utils/pdfExport";
import BalanceCard from "../components/BalanceCard";
import PieChart from "../components/PieChart";
import TransactionTable from "../components/TransactionTable";
import BudgetProgress from "../components/BudgetProgress";
import EmptyState from "../components/EmptyState";
import Loader from "../components/Loader";

const Reports = () => {
  const { user } = useAuth();
  const [month, setMonth] = useState(currentMonthInput()); // "YYYY-MM"
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!month) return;
    const [year, m] = month.split("-").map(Number);
    setLoading(true);
    getMonthlyReport(m, year)
      .then(setReport)
      .catch((err) => toast.error(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [month]);

  const download = () => {
    generateReportPDF(user, report);
    toast.success("PDF downloaded");
  };

  const label = report ? `${MONTH_NAMES[report.month - 1]} ${report.year}` : "";

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-800 dark:text-white">Reports</h1>
          <p className="text-sm text-slate-500">Monthly summary of your income and spending.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <input type="month" className="input !w-auto" value={month} max={currentMonthInput()} onChange={(e) => e.target.value && setMonth(e.target.value)} aria-label="Select month" />
          <button onClick={download} disabled={!report || loading} className="btn-primary"><FiDownload /> Export PDF</button>
        </div>
      </div>

      {loading ? (
        <Loader text="Generating report..." />
      ) : !report ? (
        <EmptyState title="Could not load report" />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-3">
            <BalanceCard title="Total Income" amount={report.totalIncome} icon={FiTrendingUp} gradient="bg-gradient-to-br from-emerald-400 to-teal-600" subtitle={label} />
            <BalanceCard title="Total Expense" amount={report.totalExpense} icon={FiTrendingDown} gradient="bg-gradient-to-br from-rose-400 to-red-600" subtitle={label} />
            <BalanceCard title="Savings" amount={report.savings} icon={FiPieChart} gradient="bg-gradient-to-br from-sky-400 to-blue-600" subtitle={label} />
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <PieChart data={report.categoryBreakdown} title="Category-wise Spending" />
            <div className="card animate-slideUp">
              <h3 className="mb-4 font-semibold text-slate-800 dark:text-white">Spending Breakdown</h3>
              {report.categoryBreakdown.length === 0 ? (
                <EmptyState title="No expenses" message={`No expenses recorded for ${label}.`} />
              ) : (
                <div className="space-y-4">
                  {report.categoryBreakdown.map((c, i) => (
                    <div key={c.category}>
                      <div className="mb-1.5 flex justify-between text-sm">
                        <span className="font-medium text-slate-700 dark:text-slate-200">{c.category}</span>
                        <span className="text-slate-500">{formatCurrency(c.total)} · {c.percentage}%</span>
                      </div>
                      <div className="h-2.5 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                        <div className="h-full rounded-full transition-all duration-700" style={{ width: `${c.percentage}%`, background: CHART_COLORS[i % CHART_COLORS.length] }} />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <BudgetProgress budget={report.budget} onEdit={() => toast.info("Change your budget from the Dashboard page")} />

          <div className="card animate-slideUp">
            <h3 className="mb-4 font-semibold text-slate-800 dark:text-white">Transactions in {label}</h3>
            {report.transactions.length === 0 ? (
              <EmptyState title="No transactions" message={`Nothing recorded for ${label}.`} />
            ) : (
              <TransactionTable transactions={report.transactions} />
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default Reports;
