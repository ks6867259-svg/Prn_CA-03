import { useEffect, useState, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { FiSearch, FiFilter, FiPlus, FiX, FiAlertTriangle } from "react-icons/fi";
import { getTransactions, deleteTransaction } from "../services/transactionService";
import { getErrorMessage, formatCurrency } from "../utils/format";
import { ALL_CATEGORIES } from "../utils/constants";
import useDebounce from "../hooks/useDebounce";
import TransactionTable from "../components/TransactionTable";
import Pagination from "../components/Pagination";
import EmptyState from "../components/EmptyState";
import Modal from "../components/Modal";
import Loader from "../components/Loader";

const initialFilters = { type: "", category: "", startDate: "", endDate: "", minAmount: "", maxAmount: "", sort: "newest" };

const Transactions = () => {
  const navigate = useNavigate();
  const [result, setResult] = useState({ data: [], page: 1, pages: 1, total: 0 });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState(initialFilters);
  const [page, setPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);
  const [toDelete, setToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const debouncedSearch = useDebounce(search); // instant search without spamming the API
  const debouncedFilters = useDebounce(filters, 500); // wait while typing amounts

  const load = useCallback(async () => {
    setLoading(true);
    try {
      // Remove empty params
      const params = Object.fromEntries(
        Object.entries({ ...debouncedFilters, search: debouncedSearch, page, limit: 8 }).filter(([, v]) => v !== "")
      );
      setResult(await getTransactions(params));
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [debouncedFilters, debouncedSearch, page]);

  useEffect(() => { load(); }, [load]);

  // Any change to search/filters returns to page 1
  useEffect(() => { setPage(1); }, [debouncedSearch, debouncedFilters]);

  const setFilter = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));
  const hasActive = search || JSON.stringify(filters) !== JSON.stringify(initialFilters);
  const reset = () => { setSearch(""); setFilters(initialFilters); };

  const confirmDelete = async () => {
    setDeleting(true);
    try {
      await deleteTransaction(toDelete._id);
      toast.success("Transaction deleted");
      setToDelete(null);
      // If we deleted the last item on a page, go back one page
      if (result.data.length === 1 && page > 1) setPage(page - 1);
      else load();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-800 dark:text-white">Transactions</h1>
          <p className="text-sm text-slate-500">Search, filter and manage all your transactions.</p>
        </div>
        <Link to="/transactions/add" className="btn-primary"><FiPlus /> Add Transaction</Link>
      </div>

      <div className="card space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input className="input !pl-11" placeholder="Search by title, notes or category..." value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <select className="input sm:w-44" value={filters.sort} onChange={setFilter("sort")} aria-label="Sort">
            <option value="newest">Newest first</option>
            <option value="oldest">Oldest first</option>
            <option value="highest">Highest amount</option>
            <option value="lowest">Lowest amount</option>
          </select>
          <button onClick={() => setShowFilters((s) => !s)} className="btn-secondary"><FiFilter /> Filters</button>
        </div>

        {showFilters && (
          <div className="grid gap-4 border-t border-slate-100 pt-4 animate-fadeIn dark:border-slate-800 sm:grid-cols-2 lg:grid-cols-3">
            <div>
              <label className="label">Type</label>
              <select className="input" value={filters.type} onChange={setFilter("type")}>
                <option value="">All</option><option value="income">Income</option><option value="expense">Expense</option>
              </select>
            </div>
            <div>
              <label className="label">Category</label>
              <select className="input" value={filters.category} onChange={setFilter("category")}>
                <option value="">All categories</option>
                {ALL_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="label">Min ₹</label><input type="number" min="0" className="input" value={filters.minAmount} onChange={setFilter("minAmount")} /></div>
              <div><label className="label">Max ₹</label><input type="number" min="0" className="input" value={filters.maxAmount} onChange={setFilter("maxAmount")} /></div>
            </div>
            <div><label className="label">From date</label><input type="date" className="input" value={filters.startDate} onChange={setFilter("startDate")} /></div>
            <div><label className="label">To date</label><input type="date" className="input" value={filters.endDate} onChange={setFilter("endDate")} /></div>
          </div>
        )}

        {hasActive && (
          <button onClick={reset} className="inline-flex items-center gap-1.5 text-sm font-medium text-red-500 hover:underline"><FiX /> Clear search & filters</button>
        )}
      </div>

      <div className="card">
        {loading ? (
          <Loader />
        ) : result.data.length === 0 ? (
          <EmptyState
            title={hasActive ? "No matching transactions" : "No transactions yet"}
            message={hasActive ? "Try changing or clearing your filters." : "Add your first income or expense to see it here."}
            action={!hasActive && <Link to="/transactions/add" className="btn-primary">Add Transaction</Link>}
          />
        ) : (
          <>
            <TransactionTable transactions={result.data} onEdit={(t) => navigate(`/transactions/edit/${t._id}`)} onDelete={setToDelete} />
            <Pagination page={result.page} pages={result.pages} total={result.total} onChange={setPage} />
          </>
        )}
      </div>

      {/* Delete confirmation */}
      <Modal isOpen={Boolean(toDelete)} onClose={() => setToDelete(null)} title="Delete transaction?">
        <div className="flex items-start gap-3 rounded-xl bg-red-50 p-3 text-sm text-red-600 dark:bg-red-500/10 dark:text-red-400">
          <FiAlertTriangle className="mt-0.5 shrink-0" />
          <p>
            <strong>{toDelete?.title}</strong> ({toDelete && formatCurrency(toDelete.amount)}) will be permanently deleted. This cannot be undone.
          </p>
        </div>
        <div className="mt-5 flex gap-3">
          <button onClick={() => setToDelete(null)} className="btn-secondary flex-1">Cancel</button>
          <button onClick={confirmDelete} disabled={deleting} className="btn-danger flex-1">{deleting ? "Deleting..." : "Delete"}</button>
        </div>
      </Modal>
    </div>
  );
};

export default Transactions;
