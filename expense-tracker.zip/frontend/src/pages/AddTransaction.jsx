import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import { createTransaction, getTransaction, updateTransaction } from "../services/transactionService";
import { getErrorMessage } from "../utils/format";
import TransactionForm from "../components/TransactionForm";
import Loader from "../components/Loader";

/** Used for both /transactions/add and /transactions/edit/:id */
const AddTransaction = () => {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const [initial, setInitial] = useState(null);
  const [loading, setLoading] = useState(isEdit);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!isEdit) return;
    getTransaction(id)
      .then(setInitial)
      .catch((err) => {
        toast.error(getErrorMessage(err));
        navigate("/transactions");
      })
      .finally(() => setLoading(false));
  }, [id, isEdit, navigate]);

  const handleSubmit = async (data) => {
    setSubmitting(true);
    try {
      if (isEdit) await updateTransaction(id, data);
      else await createTransaction(data);
      toast.success(isEdit ? "Transaction updated" : "Transaction added");
      navigate("/transactions");
    } catch (err) {
      toast.error(getErrorMessage(err));
      setSubmitting(false);
    }
  };

  if (loading) return <Loader />;

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="text-2xl font-extrabold text-slate-800 dark:text-white">{isEdit ? "Edit Transaction" : "Add Transaction"}</h1>
      <p className="mb-6 text-sm text-slate-500">{isEdit ? "Update the details below." : "Record a new income or expense."}</p>
      <div className="card !p-6">
        <TransactionForm initial={initial} onSubmit={handleSubmit} submitting={submitting} submitLabel={isEdit ? "Update Transaction" : "Add Transaction"} />
      </div>
    </div>
  );
};

export default AddTransaction;
