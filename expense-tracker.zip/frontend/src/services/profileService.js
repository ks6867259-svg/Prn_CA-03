import api from "./api";

export const getProfile = () => api.get("/profile").then((r) => r.data.user);
// data can be a plain object or FormData (when uploading an image)
export const updateProfile = (data) => api.put("/profile", data).then((r) => r.data.user);
