import api from "./api";

export const getBudget = (params) => api.get("/budget", { params }).then((r) => r.data.data);
export const setBudget = (data) => api.post("/budget", data).then((r) => r.data.data);
