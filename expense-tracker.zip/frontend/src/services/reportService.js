import api from "./api";

export const getDashboard = () => api.get("/reports/dashboard").then((r) => r.data.data);
export const getMonthlyReport = (month, year) =>
  api.get("/reports", { params: { month, year } }).then((r) => r.data.data);
