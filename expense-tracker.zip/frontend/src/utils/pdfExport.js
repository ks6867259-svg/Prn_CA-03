import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { MONTH_NAMES } from "./constants";

// jsPDF's built-in fonts cannot draw the ₹ symbol, so the PDF uses "Rs."
const money = (n = 0) =>
  `Rs. ${Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const fmtDate = (d) =>
  new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" });

/**
 * Builds and downloads a professional monthly PDF report.
 * @param {object} user   - logged in user ({ name, email })
 * @param {object} report - response data from GET /api/reports
 */
export const generateReportPDF = (user, report) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const monthLabel = `${MONTH_NAMES[report.month - 1]} ${report.year}`;

  /* ----- Header banner ----- */
  doc.setFillColor(79, 70, 229);
  doc.rect(0, 0, pageWidth, 36, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.text("Monthly Expense Report", 14, 17);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.text(`${monthLabel}`, 14, 27);
  doc.text(`Generated: ${new Date().toLocaleDateString("en-IN")}`, pageWidth - 14, 27, { align: "right" });

  /* ----- User info ----- */
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.text("Account Holder", 14, 48);
  doc.setFont("helvetica", "normal");
  doc.text(`${user.name}  (${user.email})`, 14, 55);

  /* ----- Summary ----- */
  autoTable(doc, {
    startY: 62,
    head: [["Total Income", "Total Expense", "Savings"]],
    body: [[money(report.totalIncome), money(report.totalExpense), money(report.savings)]],
    theme: "grid",
    headStyles: { fillColor: [79, 70, 229], halign: "center" },
    bodyStyles: { halign: "center", fontStyle: "bold", fontSize: 12 },
  });

  /* ----- Category breakdown ----- */
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text("Category Breakdown (Expenses)", 14, doc.lastAutoTable.finalY + 14);
  autoTable(doc, {
    startY: doc.lastAutoTable.finalY + 18,
    head: [["Category", "Amount", "Share"]],
    body: report.categoryBreakdown.length
      ? report.categoryBreakdown.map((c) => [c.category, money(c.total), `${c.percentage}%`])
      : [["No expenses recorded", "-", "-"]],
    headStyles: { fillColor: [99, 102, 241] },
    alternateRowStyles: { fillColor: [244, 245, 255] },
    columnStyles: { 1: { halign: "right" }, 2: { halign: "right" } },
  });

  /* ----- Transaction table ----- */
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text("Transactions", 14, doc.lastAutoTable.finalY + 14);
  autoTable(doc, {
    startY: doc.lastAutoTable.finalY + 18,
    head: [["Date", "Title", "Category", "Type", "Amount"]],
    body: report.transactions.length
      ? report.transactions.map((t) => [
          fmtDate(t.date),
          t.title,
          t.category,
          t.type === "income" ? "Income" : "Expense",
          `${t.type === "income" ? "+" : "-"} ${money(t.amount)}`,
        ])
      : [["No transactions this month", "", "", "", ""]],
    headStyles: { fillColor: [99, 102, 241] },
    alternateRowStyles: { fillColor: [244, 245, 255] },
    columnStyles: { 4: { halign: "right" } },
    didParseCell: (data) => {
      // Green for income, red for expense amounts
      if (data.section === "body" && data.column.index === 4) {
        const isIncome = data.row.raw[3] === "Income";
        data.cell.styles.textColor = isIncome ? [16, 185, 129] : [239, 68, 68];
      }
    },
  });

  /* ----- Footer with page numbers ----- */
  const pages = doc.internal.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setFontSize(9);
    doc.setTextColor(120);
    doc.text(`ExpenseTracker  |  Page ${i} of ${pages}`, pageWidth / 2, 288, { align: "center" });
  }

  doc.save(`expense-report-${report.year}-${String(report.month).padStart(2, "0")}.pdf`);
};
