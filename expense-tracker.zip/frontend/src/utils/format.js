import { SERVER_URL } from "./constants";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 2,
});

/** 12500 -> ₹12,500.00 */
export const formatCurrency = (n = 0) => currency.format(n);

/** Dates are stored as UTC midnight, so format in UTC to avoid off-by-one days. */
export const formatDate = (d) =>
  new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" });

/** Date -> "YYYY-MM-DD" for <input type="date"> (UTC based). */
export const toInputDate = (d) => new Date(d).toISOString().slice(0, 10);

/** Today's date as "YYYY-MM-DD" in the user's local timezone. */
export const todayInput = () => {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
};

/** Current month as "YYYY-MM" (for <input type="month">). */
export const currentMonthInput = () => todayInput().slice(0, 7);

/** Turns the stored image path ("uploads/x.jpg") into a full URL. */
export const imageUrl = (path) => (path ? `${SERVER_URL}/${path}` : "");

/** Pulls a readable message out of an Axios error. */
export const getErrorMessage = (err) =>
  err?.response?.data?.message || err?.message || "Something went wrong";
