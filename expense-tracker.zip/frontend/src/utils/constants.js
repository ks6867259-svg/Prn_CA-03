export const INCOME_CATEGORIES = ["Salary", "Freelance", "Scholarship", "Gift", "Other"];
export const EXPENSE_CATEGORIES = [
  "Food", "Shopping", "Education", "Travel", "Bills",
  "Entertainment", "Medical", "Rent", "Other",
];
export const ALL_CATEGORIES = [...new Set([...INCOME_CATEGORIES, ...EXPENSE_CATEGORIES])];

export const SERVER_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";
export const API_URL = `${SERVER_URL}/api`;

export const CHART_COLORS = [
  "#6366f1", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6",
  "#06b6d4", "#ec4899", "#84cc16", "#64748b",
];

export const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];
