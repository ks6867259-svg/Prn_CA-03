import { formatCurrency } from "../utils/format";

/** Summary card used on the dashboard (balance, income, expenses...). */
const BalanceCard = ({ title, amount, icon: Icon, gradient, subtitle }) => (
  <div className="card group relative overflow-hidden animate-slideUp hover:-translate-y-1 hover:shadow-lg">
    <div className={`absolute -right-6 -top-6 h-24 w-24 rounded-full opacity-10 transition group-hover:scale-125 ${gradient}`} />
    <div className="flex items-start justify-between">
      <div className="min-w-0">
        <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{title}</p>
        <h3 className="mt-2 truncate text-2xl font-bold text-slate-800 dark:text-white">{formatCurrency(amount)}</h3>
        {subtitle && <p className="mt-1 text-xs text-slate-400">{subtitle}</p>}
      </div>
      <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-white shadow-lg ${gradient}`}>
        <Icon size={20} />
      </div>
    </div>
  </div>
);

export default BalanceCard;
