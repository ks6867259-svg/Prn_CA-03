import { imageUrl } from "../utils/format";

/** Shows the profile picture, or the user's initial on a gradient circle. */
const Avatar = ({ user, size = "h-10 w-10", text = "text-base" }) =>
  user?.profileImage ? (
    <img src={imageUrl(user.profileImage)} alt={user.name} className={`${size} rounded-full object-cover ring-2 ring-white dark:ring-slate-800`} />
  ) : (
    <div className={`${size} ${text} flex items-center justify-center rounded-full bg-gradient-to-br from-primary-500 to-violet-600 font-bold text-white`}>
      {user?.name?.charAt(0).toUpperCase() || "?"}
    </div>
  );

export default Avatar;
