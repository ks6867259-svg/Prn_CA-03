import { FiChevronLeft, FiChevronRight } from "react-icons/fi";

const Pagination = ({ page, pages, total, onChange }) => {
  if (pages <= 1) return null;
  const btn = "flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-600 transition hover:bg-slate-100 disabled:opacity-40 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800";

  // Show a small window of page numbers around the current page
  const nums = [];
  for (let i = Math.max(1, page - 1); i <= Math.min(pages, page + 1); i++) nums.push(i);

  return (
    <div className="mt-4 flex flex-col items-center justify-between gap-3 sm:flex-row">
      <p className="text-sm text-slate-500">Page {page} of {pages} · {total} transactions</p>
      <div className="flex items-center gap-1.5">
        <button className={btn} disabled={page === 1} onClick={() => onChange(page - 1)} aria-label="Previous page"><FiChevronLeft /></button>
        {nums.map((n) => (
          <button
            key={n}
            onClick={() => onChange(n)}
            className={`h-9 w-9 rounded-lg text-sm font-medium transition ${n === page ? "bg-gradient-to-r from-primary-600 to-violet-600 text-white" : "border border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"}`}
          >
            {n}
          </button>
        ))}
        <button className={btn} disabled={page === pages} onClick={() => onChange(page + 1)} aria-label="Next page"><FiChevronRight /></button>
      </div>
    </div>
  );
};

export default Pagination;
