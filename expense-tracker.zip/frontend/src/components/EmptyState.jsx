import { FiInbox } from "react-icons/fi";

/** Friendly message shown when a list has no data. */
const EmptyState = ({ title = "Nothing here yet", message, action, icon: Icon = FiInbox }) => (
  <div className="flex flex-col items-center justify-center px-4 py-12 text-center">
    <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary-50 text-primary-500 dark:bg-slate-800">
      <Icon size={30} />
    </div>
    <h4 className="text-base font-semibold text-slate-700 dark:text-slate-200">{title}</h4>
    {message && <p className="mt-1 max-w-xs text-sm text-slate-500">{message}</p>}
    {action && <div className="mt-5">{action}</div>}
  </div>
);

export default EmptyState;
