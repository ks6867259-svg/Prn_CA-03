/** Spinner. Use fullScreen for page-level loading. */
const Loader = ({ fullScreen = false, text }) => {
  const spinner = (
    <div className="flex flex-col items-center justify-center gap-3 py-10">
      <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary-200 border-t-primary-600 dark:border-slate-700 dark:border-t-primary-400" />
      {text && <p className="text-sm text-slate-500">{text}</p>}
    </div>
  );
  if (!fullScreen) return spinner;
  return <div className="flex min-h-screen items-center justify-center">{spinner}</div>;
};

export default Loader;
