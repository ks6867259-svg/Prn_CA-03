import { FiTrendingUp } from "react-icons/fi";
import { useTheme } from "../context/ThemeContext";
import { FiMoon, FiSun } from "react-icons/fi";

/** Split-screen wrapper used by Login and Register. */
const AuthLayout = ({ title, subtitle, children }) => {
  const { theme, toggleTheme } = useTheme();
  return (
    <div className="flex min-h-screen">
      {/* Left: brand panel (hidden on small screens) */}
      <div className="relative hidden w-1/2 flex-col justify-between overflow-hidden bg-gradient-to-br from-primary-600 via-violet-600 to-fuchsia-600 p-12 text-white lg:flex">
        <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-white/10" />
        <div className="absolute -bottom-24 -left-16 h-80 w-80 rounded-full bg-white/10" />
        <div className="relative flex items-center gap-3 text-xl font-extrabold">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/20 backdrop-blur"><FiTrendingUp size={22} /></div>
          ExpenseTracker
        </div>
        <div className="relative">
          <h1 className="text-4xl font-extrabold leading-tight">Take control of<br />your money.</h1>
          <p className="mt-4 max-w-sm text-white/80">Track income and expenses, set monthly budgets, and understand your spending with beautiful charts and reports.</p>
        </div>
        <p className="relative text-sm text-white/60">© {new Date().getFullYear()} ExpenseTracker</p>
      </div>

      {/* Right: form */}
      <div className="relative flex flex-1 items-center justify-center p-6">
        <button onClick={toggleTheme} aria-label="Toggle dark mode" className="absolute right-5 top-5 rounded-xl border border-slate-200 p-2.5 text-slate-600 dark:border-slate-700 dark:text-amber-300">
          {theme === "dark" ? <FiSun size={18} /> : <FiMoon size={18} />}
        </button>
        <div className="w-full max-w-md animate-slideUp">
          <h2 className="text-3xl font-extrabold text-slate-800 dark:text-white">{title}</h2>
          <p className="mb-8 mt-2 text-slate-500">{subtitle}</p>
          {children}
        </div>
      </div>
    </div>
  );
};

export default AuthLayout;
