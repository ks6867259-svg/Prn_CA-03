import { NavLink } from "react-router-dom";
import { FiHome, FiList, FiPlusCircle, FiBarChart2, FiUser, FiLogOut, FiTrendingUp, FiX } from "react-icons/fi";
import { useAuth } from "../context/AuthContext";

const links = [
  { to: "/", label: "Dashboard", icon: FiHome, end: true },
  { to: "/transactions", label: "Transactions", icon: FiList, end: true },
  { to: "/transactions/add", label: "Add Transaction", icon: FiPlusCircle },
  { to: "/reports", label: "Reports", icon: FiBarChart2 },
  { to: "/profile", label: "Profile", icon: FiUser },
];

/** Fixed on desktop, slide-in drawer on mobile/tablet. */
const Sidebar = ({ open, onClose }) => {
  const { logout } = useAuth();

  return (
    <>
      {/* Mobile backdrop */}
      {open && <div className="fixed inset-0 z-30 bg-slate-900/50 backdrop-blur-sm lg:hidden" onClick={onClose} />}

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-slate-100 bg-white px-4 py-6 transition-transform duration-300 dark:border-slate-800 dark:bg-slate-900 lg:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}
      >
        <div className="mb-8 flex items-center justify-between px-2">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-violet-600 text-white shadow-lg shadow-primary-500/30">
              <FiTrendingUp size={20} />
            </div>
            <span className="text-lg font-extrabold tracking-tight text-slate-800 dark:text-white">ExpenseTracker</span>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden" aria-label="Close menu">
            <FiX size={20} />
          </button>
        </div>

        <nav className="flex-1 space-y-1">
          {links.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition ${
                  isActive
                    ? "bg-gradient-to-r from-primary-600 to-violet-600 text-white shadow-lg shadow-primary-500/25"
                    : "text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
                }`
              }
            >
              <Icon size={18} /> {label}
            </NavLink>
          ))}
        </nav>

        <button
          onClick={logout}
          className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-red-500 transition hover:bg-red-50 dark:hover:bg-red-500/10"
        >
          <FiLogOut size={18} /> Logout
        </button>
      </aside>
    </>
  );
};

export default Sidebar;
