import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import Loader from "./Loader";

/** Wrap a route: redirects to /login if not authenticated. */
export const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <Loader fullScreen text="Loading..." />;
  return user ? children : <Navigate to="/login" replace />;
};

/** Login/Register pages: logged-in users are sent to the dashboard. */
export const PublicRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <Loader fullScreen text="Loading..." />;
  return user ? <Navigate to="/" replace /> : children;
};
