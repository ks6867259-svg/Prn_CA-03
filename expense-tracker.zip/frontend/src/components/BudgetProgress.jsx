import { FiAlertTriangle, FiEdit2 } from "react-icons/fi";
import { formatCurrency } from "../utils/format";

/** Progress bar showing Budget / Spent / Remaining + warning at 90%. */
const BudgetProgress = ({ budget, onEdit }) => {
  const { monthlyBudget, spent, remaining, percentage, isSet } = budget;
  const barColor = percentage >= 90 ? "bg-red-500" : percentage >= 70 ? "bg-amber-500" : "bg-emerald-500";

  return (
    <div className="card animate-slideUp">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-semibold text-slate-800 dark:text-white">Monthly Budget</h3>
        <button onClick={onEdit} className="btn-secondary !px-3 !py-1.5 text-xs">
          <FiEdit2 size={13} /> {isSet ? "Edit" : "Set budget"}
        </button>
      </div>

      {!isSet ? (
        <p className="py-6 text-center text-sm text-slate-500">You haven't set a budget for this month yet.</p>
      ) : (
        <>
          <div className="mb-2 flex justify-between text-sm">
            <span className="text-slate-500">{percentage}% used</span>
            <span className="font-medium text-slate-700 dark:text-slate-200">{formatCurrency(spent)} / {formatCurrency(monthlyBudget)}</span>
          </div>
          <div className="h-3 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
            <div className={`h-full rounded-full transition-all duration-700 ${barColor}`} style={{ width: `${Math.min(percentage, 100)}%` }} />
          </div>

          <div className="mt-4 grid grid-cols-3 gap-2 text-center">
            {[
              ["Budget", formatCurrency(monthlyBudget), "text-slate-700 dark:text-slate-200"],
              ["Spent", formatCurrency(spent), "text-red-500"],
              ["Remaining", formatCurrency(remaining), remaining < 0 ? "text-red-500" : "text-emerald-500"],
            ].map(([label, value, color]) => (
              <div key={label} className="rounded-xl bg-slate-50 p-2.5 dark:bg-slate-800/60">
                <p className="text-xs text-slate-400">{label}</p>
                <p className={`mt-0.5 truncate text-sm font-bold ${color}`}>{value}</p>
              </div>
            ))}
          </div>

          {percentage >= 90 && (
            <div className="mt-4 flex items-start gap-2 rounded-xl bg-red-50 p-3 text-sm text-red-600 dark:bg-red-500/10 dark:text-red-400">
              <FiAlertTriangle className="mt-0.5 shrink-0" />
              <span>{percentage >= 100 ? "You have exceeded your monthly budget!" : "Warning: you have used 90% or more of your monthly budget."}</span>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default BudgetProgress;
