import { FiEdit2, FiTrash2 } from "react-icons/fi";
import { formatCurrency, formatDate } from "../utils/format";

const TypeBadge = ({ type }) => (
  <span className={`rounded-full px-2.5 py-1 text-xs font-semibold capitalize ${type === "income" ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400" : "bg-red-50 text-red-600 dark:bg-red-500/10 dark:text-red-400"}`}>
    {type}
  </span>
);

const Amount = ({ t }) => (
  <span className={`font-bold ${t.type === "income" ? "text-emerald-500" : "text-red-500"}`}>
    {t.type === "income" ? "+" : "-"}{formatCurrency(t.amount)}
  </span>
);

/**
 * Table on desktop, card list on mobile.
 * Pass onEdit/onDelete to show the action buttons.
 */
const TransactionTable = ({ transactions, onEdit, onDelete }) => {
  const showActions = Boolean(onEdit || onDelete);

  const Actions = ({ t }) =>
    showActions && (
      <div className="flex items-center justify-end gap-1">
        {onEdit && <button onClick={() => onEdit(t)} aria-label="Edit" className="rounded-lg p-2 text-slate-400 transition hover:bg-primary-50 hover:text-primary-600 dark:hover:bg-slate-800"><FiEdit2 size={16} /></button>}
        {onDelete && <button onClick={() => onDelete(t)} aria-label="Delete" className="rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-500 dark:hover:bg-slate-800"><FiTrash2 size={16} /></button>}
      </div>
    );

  return (
    <>
      {/* Desktop table */}
      <div className="hidden overflow-x-auto md:block">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400 dark:border-slate-800">
              <th className="py-3 pr-4 font-semibold">Title</th>
              <th className="py-3 pr-4 font-semibold">Category</th>
              <th className="py-3 pr-4 font-semibold">Date</th>
              <th className="py-3 pr-4 font-semibold">Type</th>
              <th className="py-3 pr-4 text-right font-semibold">Amount</th>
              {showActions && <th className="py-3 text-right font-semibold">Actions</th>}
            </tr>
          </thead>
          <tbody>
            {transactions.map((t) => (
              <tr key={t._id} className="border-b border-slate-50 transition hover:bg-slate-50/70 dark:border-slate-800/60 dark:hover:bg-slate-800/40">
                <td className="max-w-[220px] py-3.5 pr-4">
                  <p className="truncate font-medium text-slate-800 dark:text-slate-100">{t.title}</p>
                  {t.notes && <p className="truncate text-xs text-slate-400">{t.notes}</p>}
                </td>
                <td className="py-3.5 pr-4 text-slate-600 dark:text-slate-300">{t.category}</td>
                <td className="whitespace-nowrap py-3.5 pr-4 text-slate-500">{formatDate(t.date)}</td>
                <td className="py-3.5 pr-4"><TypeBadge type={t.type} /></td>
                <td className="whitespace-nowrap py-3.5 pr-4 text-right"><Amount t={t} /></td>
                {showActions && <td className="py-3.5"><Actions t={t} /></td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="space-y-3 md:hidden">
        {transactions.map((t) => (
          <div key={t._id} className="rounded-xl border border-slate-100 p-3.5 dark:border-slate-800">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="truncate font-semibold text-slate-800 dark:text-slate-100">{t.title}</p>
                <p className="text-xs text-slate-400">{t.category} · {formatDate(t.date)}</p>
              </div>
              <Amount t={t} />
            </div>
            <div className="mt-2 flex items-center justify-between">
              <TypeBadge type={t.type} />
              <Actions t={t} />
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default TransactionTable;
