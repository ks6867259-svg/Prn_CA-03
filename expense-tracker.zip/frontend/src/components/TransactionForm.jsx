import { useState } from "react";
import { FiArrowDownCircle, FiArrowUpCircle } from "react-icons/fi";
import { INCOME_CATEGORIES, EXPENSE_CATEGORIES } from "../utils/constants";
import { todayInput, toInputDate } from "../utils/format";

const emptyForm = () => ({ title: "", amount: "", type: "expense", category: "", date: todayInput(), notes: "" });

/**
 * Shared form for adding and editing a transaction.
 * Pass `initial` (a transaction) to pre-fill it for editing.
 */
const TransactionForm = ({ initial, onSubmit, submitting, submitLabel = "Save Transaction" }) => {
  const [form, setForm] = useState(
    initial ? { ...initial, amount: String(initial.amount), date: toInputDate(initial.date), notes: initial.notes || "" } : emptyForm()
  );
  const [errors, setErrors] = useState({});

  const categories = form.type === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  const setField = (name, value) => {
    setForm((f) => ({ ...f, [name]: value }));
    setErrors((e) => ({ ...e, [name]: "" }));
  };

  // Changing type resets the category (lists are different)
  const setType = (type) => {
    setForm((f) => ({ ...f, type, category: "" }));
    setErrors((e) => ({ ...e, category: "" }));
  };

  const validate = () => {
    const e = {};
    if (!form.title.trim()) e.title = "Title is required";
    if (!form.amount || Number(form.amount) <= 0) e.amount = "Enter an amount greater than 0";
    if (!form.category) e.category = "Please select a category";
    if (!form.date) e.date = "Date is required";
    if (form.notes.length > 300) e.notes = "Notes must be under 300 characters";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    onSubmit({
      title: form.title.trim(),
      amount: Number(form.amount),
      type: form.type,
      category: form.category,
      date: form.date,
      notes: form.notes.trim(),
    });
  };

  const typeBtn = (type, label, Icon, active) => (
    <button
      type="button"
      onClick={() => setType(type)}
      className={`flex flex-1 items-center justify-center gap-2 rounded-xl border-2 px-4 py-3 text-sm font-semibold transition ${
        form.type === type ? active : "border-slate-200 text-slate-500 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
      }`}
    >
      <Icon size={18} /> {label}
    </button>
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-5" noValidate>
      <div className="flex gap-3">
        {typeBtn("expense", "Expense", FiArrowUpCircle, "border-red-500 bg-red-50 text-red-600 dark:bg-red-500/10")}
        {typeBtn("income", "Income", FiArrowDownCircle, "border-emerald-500 bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10")}
      </div>

      <div>
        <label className="label" htmlFor="title">Title</label>
        <input id="title" className={`input ${errors.title ? "input-error" : ""}`} placeholder="e.g. Grocery shopping" value={form.title} onChange={(e) => setField("title", e.target.value)} />
        {errors.title && <p className="error-text">{errors.title}</p>}
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="amount">Amount (₹)</label>
          <input id="amount" type="number" min="0" step="0.01" className={`input ${errors.amount ? "input-error" : ""}`} placeholder="0.00" value={form.amount} onChange={(e) => setField("amount", e.target.value)} />
          {errors.amount && <p className="error-text">{errors.amount}</p>}
        </div>
        <div>
          <label className="label" htmlFor="date">Date</label>
          <input id="date" type="date" className={`input ${errors.date ? "input-error" : ""}`} value={form.date} onChange={(e) => setField("date", e.target.value)} />
          {errors.date && <p className="error-text">{errors.date}</p>}
        </div>
      </div>

      <div>
        <label className="label" htmlFor="category">Category</label>
        <select id="category" className={`input ${errors.category ? "input-error" : ""}`} value={form.category} onChange={(e) => setField("category", e.target.value)}>
          <option value="">Select a category</option>
          {categories.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        {errors.category && <p className="error-text">{errors.category}</p>}
      </div>

      <div>
        <label className="label" htmlFor="notes">Notes <span className="text-slate-400">(optional)</span></label>
        <textarea id="notes" rows={3} className={`input resize-none ${errors.notes ? "input-error" : ""}`} placeholder="Add any extra details..." value={form.notes} onChange={(e) => setField("notes", e.target.value)} />
        {errors.notes && <p className="error-text">{errors.notes}</p>}
      </div>

      <button type="submit" disabled={submitting} className="btn-primary w-full">
        {submitting ? "Saving..." : submitLabel}
      </button>
    </form>
  );
};

export default TransactionForm;
