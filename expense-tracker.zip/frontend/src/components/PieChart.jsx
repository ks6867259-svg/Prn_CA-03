import { ResponsiveContainer, PieChart as RPieChart, Pie, Cell, Tooltip, Legend } from "recharts";
import { formatCurrency } from "../utils/format";
import { CHART_COLORS } from "../utils/constants";
import EmptyState from "./EmptyState";

/** Pie chart: expense by category. data = [{ category, total }, ...] */
const PieChart = ({ data, title = "Expense by Category" }) => (
  <div className="card animate-slideUp">
    <h3 className="mb-4 font-semibold text-slate-800 dark:text-white">{title}</h3>
    {data.length === 0 ? (
      <EmptyState title="No expenses yet" message="Add an expense to see your spending breakdown." />
    ) : (
      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <RPieChart>
            <Pie data={data} dataKey="total" nameKey="category" innerRadius={55} outerRadius={95} paddingAngle={3} stroke="none">
              {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
            </Pie>
            <Tooltip formatter={(v) => formatCurrency(v)} contentStyle={{ borderRadius: 12, border: "none", boxShadow: "0 8px 24px rgba(0,0,0,.15)" }} />
            <Legend iconType="circle" />
          </RPieChart>
        </ResponsiveContainer>
      </div>
    )}
  </div>
);

export default PieChart;
