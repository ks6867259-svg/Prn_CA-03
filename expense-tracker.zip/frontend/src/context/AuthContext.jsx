import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { loginUser, registerUser } from "../services/authService";
import { getProfile } from "../services/profileService";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // true while we check the saved token

  // On first load: if a token exists, fetch the user it belongs to
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return setLoading(false);
    getProfile()
      .then(setUser)
      .catch(() => localStorage.removeItem("token"))
      .finally(() => setLoading(false));
  }, []);

  const handleAuth = ({ token, user }) => {
    localStorage.setItem("token", token);
    setUser(user);
  };

  const login = async (credentials) => handleAuth(await loginUser(credentials));
  const register = async (data) => handleAuth(await registerUser(data));

  const logout = useCallback(() => {
    localStorage.removeItem("token");
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, setUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
