/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  darkMode: "class", // dark mode is toggled by adding "dark" to <html>
  theme: {
    extend: {
      fontFamily: { sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"] },
      colors: {
        primary: {
          50: "#eef2ff", 100: "#e0e7ff", 200: "#c7d2fe", 300: "#a5b4fc",
          400: "#818cf8", 500: "#6366f1", 600: "#4f46e5", 700: "#4338ca", 800: "#3730a3", 900: "#312e81",
        },
      },
      boxShadow: { soft: "0 4px 24px -6px rgba(15, 23, 42, 0.08)" },
      keyframes: {
        fadeIn: { from: { opacity: 0 }, to: { opacity: 1 } },
        slideUp: { from: { opacity: 0, transform: "translateY(12px)" }, to: { opacity: 1, transform: "translateY(0)" } },
        scaleIn: { from: { opacity: 0, transform: "scale(.95)" }, to: { opacity: 1, transform: "scale(1)" } },
      },
      animation: {
        fadeIn: "fadeIn .3s ease-out",
        slideUp: "slideUp .4s ease-out",
        scaleIn: "scaleIn .2s ease-out",
      },
    },
  },
  plugins: [],
};
