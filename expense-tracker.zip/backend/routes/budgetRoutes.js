import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import { getBudget, setBudget } from "../controllers/budgetController.js";

const router = express.Router();
router.use(protect);
router.route("/").get(getBudget).post(setBudget);

export default router;
