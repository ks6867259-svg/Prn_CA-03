import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import { getMonthlyReport, getDashboard } from "../controllers/reportController.js";

const router = express.Router();
router.use(protect);
router.get("/dashboard", getDashboard); // must be before "/"
router.get("/", getMonthlyReport);

export default router;
