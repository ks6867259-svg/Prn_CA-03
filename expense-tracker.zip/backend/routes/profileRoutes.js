import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import upload from "../middleware/uploadMiddleware.js";
import { getProfile, updateProfile } from "../controllers/profileController.js";

const router = express.Router();
router.use(protect);
router.route("/").get(getProfile).put(upload.single("profileImage"), updateProfile);

export default router;
