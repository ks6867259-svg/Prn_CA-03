import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import {
  getTransactions, getTransactionById, createTransaction, updateTransaction, deleteTransaction,
} from "../controllers/transactionController.js";

const router = express.Router();
router.use(protect); // every transaction route requires login

router.route("/").get(getTransactions).post(createTransaction);
router.route("/:id").get(getTransactionById).put(updateTransaction).delete(deleteTransaction);

export default router;
