import mongoose from "mongoose";

/**
 * Connects to MongoDB using the URI from .env.
 * If the connection fails, the process exits so we never run a broken server.
 */
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`MongoDB connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`MongoDB connection error: ${error.message}`);
    process.exit(1);
  }
};

export default connectDB;
