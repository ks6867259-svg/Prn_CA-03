import mongoose from "mongoose";
import { INCOME_CATEGORIES, EXPENSE_CATEGORIES } from "../utils/constants.js";

const transactionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  title: { type: String, required: [true, "Title is required"], trim: true, maxlength: [100, "Title too long"] },
  amount: { type: Number, required: [true, "Amount is required"], min: [0.01, "Amount must be greater than 0"] },
  type: { type: String, enum: { values: ["income", "expense"], message: "Type must be income or expense" }, required: [true, "Type is required"] },
  category: {
    type: String,
    required: [true, "Category is required"],
    validate: {
      // Category must belong to the chosen type
      validator: function (v) {
        return (this.type === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES).includes(v);
      },
      message: "Invalid category for this transaction type",
    },
  },
  notes: { type: String, trim: true, maxlength: [300, "Notes too long"], default: "" },
  date: { type: Date, required: [true, "Date is required"], default: Date.now },
  createdAt: { type: Date, default: Date.now },
});

transactionSchema.index({ userId: 1, date: -1 });

export default mongoose.model("Transaction", transactionSchema);
