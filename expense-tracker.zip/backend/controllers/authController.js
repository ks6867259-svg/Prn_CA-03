import User from "../models/User.js";
import asyncHandler from "../utils/asyncHandler.js";
import generateToken from "../utils/generateToken.js";

// Shape of the user object sent to the frontend (never includes password)
const userResponse = (user) => ({
  _id: user._id,
  name: user.name,
  email: user.email,
  profileImage: user.profileImage,
  createdAt: user.createdAt,
});

/** @route POST /api/auth/register  @access Public */
export const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    res.status(400);
    throw new Error("Name, email and password are required");
  }
  if (password.length < 6) {
    res.status(400);
    throw new Error("Password must be at least 6 characters");
  }
  if (await User.findOne({ email: email.toLowerCase() })) {
    res.status(400);
    throw new Error("Email already registered");
  }

  const user = await User.create({ name, email, password }); // hashed by pre-save hook
  res.status(201).json({ success: true, token: generateToken(user._id), user: userResponse(user) });
});

/** @route POST /api/auth/login  @access Public */
export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400);
    throw new Error("Email and password are required");
  }

  const user = await User.findOne({ email: email.toLowerCase() }).select("+password");
  if (!user || !(await user.matchPassword(password))) {
    res.status(401);
    throw new Error("Invalid email or password");
  }

  res.json({ success: true, token: generateToken(user._id), user: userResponse(user) });
});
