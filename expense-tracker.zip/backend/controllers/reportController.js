import mongoose from "mongoose";
import Transaction from "../models/Transaction.js";
import Budget from "../models/Budget.js";
import asyncHandler from "../utils/asyncHandler.js";
import { monthRange, parseMonthYear } from "../utils/dateRange.js";
import { buildBudgetSummary } from "./budgetController.js";

const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** Sums income & expense from an aggregation result [{_id:'income', total}, ...] */
const toTotals = (rows) => ({
  income: rows.find((r) => r._id === "income")?.total || 0,
  expense: rows.find((r) => r._id === "expense")?.total || 0,
});

/** Expense totals per category for a date range, with percentage share. */
const categoryBreakdown = async (userId, start, end) => {
  const rows = await Transaction.aggregate([
    { $match: { userId, type: "expense", date: { $gte: start, $lt: end } } },
    { $group: { _id: "$category", total: { $sum: "$amount" } } },
    { $sort: { total: -1 } },
  ]);
  const sum = rows.reduce((a, r) => a + r.total, 0);
  return rows.map((r) => ({
    category: r._id,
    total: r.total,
    percentage: sum ? Math.round((r.total / sum) * 1000) / 10 : 0,
  }));
};

/**
 * @route GET /api/reports?month=&year=
 * Full monthly report: totals, savings, category breakdown, all transactions.
 */
export const getMonthlyReport = asyncHandler(async (req, res) => {
  const { month, year } = parseMonthYear(req.query);
  const userId = new mongoose.Types.ObjectId(req.user._id);
  const { start, end } = monthRange(year, month);

  const totalsRows = await Transaction.aggregate([
    { $match: { userId, date: { $gte: start, $lt: end } } },
    { $group: { _id: "$type", total: { $sum: "$amount" } } },
  ]);
  const { income, expense } = toTotals(totalsRows);

  const transactions = await Transaction.find({ userId, date: { $gte: start, $lt: end } }).sort({ date: -1 });

  res.json({
    success: true,
    data: {
      month,
      year,
      totalIncome: income,
      totalExpense: expense,
      savings: income - expense,
      categoryBreakdown: await categoryBreakdown(userId, start, end),
      transactions,
      budget: await buildBudgetSummary(req.user._id, year, month),
    },
  });
});

/**
 * @route GET /api/reports/dashboard
 * Everything the dashboard needs in one request.
 */
export const getDashboard = asyncHandler(async (req, res) => {
  const userId = new mongoose.Types.ObjectId(req.user._id);
  const { month, year } = parseMonthYear({});
  const { start, end } = monthRange(year, month);

  // All-time balance
  const allTime = toTotals(
    await Transaction.aggregate([{ $match: { userId } }, { $group: { _id: "$type", total: { $sum: "$amount" } } }])
  );

  // Current month totals
  const monthTotals = toTotals(
    await Transaction.aggregate([
      { $match: { userId, date: { $gte: start, $lt: end } } },
      { $group: { _id: "$type", total: { $sum: "$amount" } } },
    ])
  );

  // Month-by-month trend for the current year (used by line + bar charts)
  const yearStart = new Date(Date.UTC(year, 0, 1));
  const yearEnd = new Date(Date.UTC(year + 1, 0, 1));
  const trendRows = await Transaction.aggregate([
    { $match: { userId, date: { $gte: yearStart, $lt: yearEnd } } },
    { $group: { _id: { m: { $month: "$date" }, type: "$type" }, total: { $sum: "$amount" } } },
  ]);
  const monthlyTrend = MONTH_NAMES.map((name, i) => ({
    name,
    income: trendRows.find((r) => r._id.m === i + 1 && r._id.type === "income")?.total || 0,
    expense: trendRows.find((r) => r._id.m === i + 1 && r._id.type === "expense")?.total || 0,
  }));

  const budget = await buildBudgetSummary(req.user._id, year, month);

  res.json({
    success: true,
    data: {
      month,
      year,
      totalBalance: allTime.income - allTime.expense,
      monthIncome: monthTotals.income,
      monthExpense: monthTotals.expense,
      monthSavings: monthTotals.income - monthTotals.expense,
      budget,
      monthlyTrend,
      categoryBreakdown: await categoryBreakdown(userId, start, end),
      recentTransactions: await Transaction.find({ userId }).sort({ date: -1, createdAt: -1 }).limit(5),
    },
  });
});
