import mongoose from "mongoose";
import Budget from "../models/Budget.js";
import Transaction from "../models/Transaction.js";
import asyncHandler from "../utils/asyncHandler.js";
import { monthRange, parseMonthYear } from "../utils/dateRange.js";

/** Total expenses of a user in a given month. */
export const getMonthlySpent = async (userId, year, month) => {
  const { start, end } = monthRange(year, month);
  const [result] = await Transaction.aggregate([
    { $match: { userId: new mongoose.Types.ObjectId(userId), type: "expense", date: { $gte: start, $lt: end } } },
    { $group: { _id: null, total: { $sum: "$amount" } } },
  ]);
  return result?.total || 0;
};

/** Builds the budget summary object returned by the API. */
export const buildBudgetSummary = async (userId, year, month) => {
  const budget = await Budget.findOne({ userId, month, year });
  const spent = await getMonthlySpent(userId, year, month);
  const monthlyBudget = budget?.monthlyBudget || 0;
  return {
    monthlyBudget,
    month,
    year,
    spent,
    remaining: monthlyBudget - spent,
    percentage: monthlyBudget ? Math.round((spent / monthlyBudget) * 100) : 0,
    isSet: Boolean(budget),
  };
};

/** @route GET /api/budget?month=&year= */
export const getBudget = asyncHandler(async (req, res) => {
  const { month, year } = parseMonthYear(req.query);
  res.json({ success: true, data: await buildBudgetSummary(req.user._id, year, month) });
});

/** @route POST /api/budget  Body: { monthlyBudget, month?, year? } (create or update) */
export const setBudget = asyncHandler(async (req, res) => {
  const { month, year } = parseMonthYear(req.body);
  const monthlyBudget = Number(req.body.monthlyBudget);

  if (!monthlyBudget || monthlyBudget <= 0) {
    res.status(400);
    throw new Error("Budget must be a number greater than 0");
  }

  await Budget.findOneAndUpdate(
    { userId: req.user._id, month, year },
    { monthlyBudget },
    { upsert: true, new: true, runValidators: true }
  );

  res.json({ success: true, data: await buildBudgetSummary(req.user._id, year, month) });
});
