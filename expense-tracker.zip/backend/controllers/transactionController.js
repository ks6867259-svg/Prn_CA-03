import Transaction from "../models/Transaction.js";
import asyncHandler from "../utils/asyncHandler.js";

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const SORT_OPTIONS = {
  newest: { date: -1, createdAt: -1 },
  oldest: { date: 1, createdAt: 1 },
  highest: { amount: -1 },
  lowest: { amount: 1 },
};

/**
 * @route GET /api/transactions
 * Query: search, type, category, startDate, endDate, minAmount, maxAmount,
 *        sort (newest|oldest|highest|lowest), page, limit
 */
export const getTransactions = asyncHandler(async (req, res) => {
  const { search, type, category, startDate, endDate, minAmount, maxAmount, sort = "newest" } = req.query;
  const page = Math.max(Number(req.query.page) || 1, 1);
  const limit = Math.min(Math.max(Number(req.query.limit) || 10, 1), 100);

  const query = { userId: req.user._id };

  if (search) {
    const rx = new RegExp(escapeRegex(search.trim()), "i");
    query.$or = [{ title: rx }, { notes: rx }, { category: rx }];
  }
  if (type && ["income", "expense"].includes(type)) query.type = type;
  if (category) query.category = category;

  if (startDate || endDate) {
    query.date = {};
    if (startDate) query.date.$gte = new Date(startDate);
    if (endDate) query.date.$lte = new Date(`${endDate}T23:59:59.999Z`); // inclusive
  }
  if (minAmount || maxAmount) {
    query.amount = {};
    if (minAmount) query.amount.$gte = Number(minAmount);
    if (maxAmount) query.amount.$lte = Number(maxAmount);
  }

  const total = await Transaction.countDocuments(query);
  const data = await Transaction.find(query)
    .sort(SORT_OPTIONS[sort] || SORT_OPTIONS.newest)
    .skip((page - 1) * limit)
    .limit(limit);

  res.json({ success: true, data, page, pages: Math.ceil(total / limit) || 1, total });
});

/** @route GET /api/transactions/:id */
export const getTransactionById = asyncHandler(async (req, res) => {
  const transaction = await Transaction.findOne({ _id: req.params.id, userId: req.user._id });
  if (!transaction) {
    res.status(404);
    throw new Error("Transaction not found");
  }
  res.json({ success: true, data: transaction });
});

/** @route POST /api/transactions */
export const createTransaction = asyncHandler(async (req, res) => {
  const { title, amount, category, type, notes, date } = req.body;
  const transaction = await Transaction.create({
    userId: req.user._id, title, amount, category, type, notes, date,
  });
  res.status(201).json({ success: true, data: transaction });
});

/** @route PUT /api/transactions/:id */
export const updateTransaction = asyncHandler(async (req, res) => {
  const transaction = await Transaction.findOne({ _id: req.params.id, userId: req.user._id });
  if (!transaction) {
    res.status(404);
    throw new Error("Transaction not found");
  }

  // Only allow these fields to be changed; save() runs full validation
  ["title", "amount", "category", "type", "notes", "date"].forEach((field) => {
    if (req.body[field] !== undefined) transaction[field] = req.body[field];
  });
  await transaction.save();

  res.json({ success: true, data: transaction });
});

/** @route DELETE /api/transactions/:id */
export const deleteTransaction = asyncHandler(async (req, res) => {
  const transaction = await Transaction.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
  if (!transaction) {
    res.status(404);
    throw new Error("Transaction not found");
  }
  res.json({ success: true, message: "Transaction deleted" });
});
