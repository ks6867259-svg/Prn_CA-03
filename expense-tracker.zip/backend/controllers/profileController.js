import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import User from "../models/User.js";
import asyncHandler from "../utils/asyncHandler.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const userResponse = (user) => ({
  _id: user._id,
  name: user.name,
  email: user.email,
  profileImage: user.profileImage,
  createdAt: user.createdAt,
});

/** Deletes an old profile image from disk (ignores errors). */
const removeImageFile = (imagePath) => {
  if (!imagePath) return;
  fs.unlink(path.join(__dirname, "..", imagePath), () => {});
};

/** @route GET /api/profile */
export const getProfile = asyncHandler(async (req, res) => {
  res.json({ success: true, user: userResponse(req.user) });
});

/**
 * @route PUT /api/profile
 * Accepts multipart/form-data or JSON:
 *   name, profileImage (file), currentPassword + newPassword
 */
export const updateProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select("+password");
  const { name, currentPassword, newPassword } = req.body;

  if (name !== undefined) {
    if (!name.trim()) {
      res.status(400);
      throw new Error("Name cannot be empty");
    }
    user.name = name.trim();
  }

  if (newPassword) {
    if (!currentPassword || !(await user.matchPassword(currentPassword))) {
      res.status(400);
      throw new Error("Current password is incorrect");
    }
    if (newPassword.length < 6) {
      res.status(400);
      throw new Error("New password must be at least 6 characters");
    }
    user.password = newPassword; // hashed by pre-save hook
  }

  if (req.file) {
    removeImageFile(user.profileImage);
    user.profileImage = `uploads/${req.file.filename}`;
  }

  await user.save();
  res.json({ success: true, message: "Profile updated", user: userResponse(user) });
});
