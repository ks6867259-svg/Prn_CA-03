/**
 * Returns the [start, end) UTC range for a given month (1-12) and year.
 * Dates are stored as UTC midnight, so we use UTC boundaries everywhere.
 */
export const monthRange = (year, month) => ({
  start: new Date(Date.UTC(year, month - 1, 1)),
  end: new Date(Date.UTC(year, month, 1)),
});

/** Reads ?month=&year= from the query, defaulting to the current month. */
export const parseMonthYear = (query) => {
  const now = new Date();
  const month = Number(query.month) || now.getUTCMonth() + 1;
  const year = Number(query.year) || now.getUTCFullYear();
  return { month, year };
};
