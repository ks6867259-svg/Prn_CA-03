export const INCOME_CATEGORIES = ["Salary", "Freelance", "Scholarship", "Gift", "Other"];
export const EXPENSE_CATEGORIES = [
  "Food", "Shopping", "Education", "Travel", "Bills",
  "Entertainment", "Medical", "Rent", "Other",
];
