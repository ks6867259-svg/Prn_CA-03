/**
 * Wraps async route handlers so any thrown error
 * is passed automatically to the error middleware.
 */
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

export default asyncHandler;
