# Expense Tracker (MERN)

React (Vite) + Tailwind + Recharts frontend, Node/Express + MongoDB backend, JWT auth.

## Prerequisites
- Node.js 18+
- MongoDB running locally (or a MongoDB Atlas URI)

## Setup

### 1. Backend
```bash
cd backend
npm install
cp .env.example .env      # Windows: copy .env.example .env
# edit .env: set MONGO_URI and a long random JWT_SECRET
npm run dev               # http://localhost:5000
```

### 2. Frontend (new terminal)
```bash
cd frontend
npm install
cp .env.example .env      # Windows: copy .env.example .env
npm run dev               # http://localhost:5173
```

Open http://localhost:5173, register an account and start adding transactions.

## API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| POST | /api/auth/register | Register |
| POST | /api/auth/login | Login |
| GET/POST | /api/transactions | List (search, filter, sort, paginate) / create |
| GET/PUT/DELETE | /api/transactions/:id | Read / update / delete |
| GET/POST | /api/budget | Get / set monthly budget |
| GET | /api/reports?month=&year= | Monthly report |
| GET | /api/reports/dashboard | Dashboard data |
| GET/PUT | /api/profile | Get / update profile (name, password, image) |

## Deployment notes
Set `NODE_ENV=production`, use a strong `JWT_SECRET`, set `CLIENT_URL` to your frontend URL,
and set `VITE_API_URL` to your backend URL before running `npm run build` in the frontend.
